gevent: Do not pull in test-suite (still to be refined)
