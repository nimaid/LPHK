setuptools: Exclude outdated compat modules.
