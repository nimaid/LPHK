Add hook for PIL.ImageFilter to not pull
numpy, which is an optional component.
