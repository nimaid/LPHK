Add hook for setuptools to not pull in numpy, which is only imported if
installed, not mean to be a dependency
