Add hook for numpy._pytesttester to not pull in pytest.
